advancement revoke @s only evola_dp:use_sod
execute anchored eyes positioned ^ ^ ^5 run function evola_dp:sod