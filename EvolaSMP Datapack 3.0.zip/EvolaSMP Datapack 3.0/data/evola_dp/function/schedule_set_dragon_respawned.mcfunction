scoreboard players set #dragon_respawned perm_data_holder 1
