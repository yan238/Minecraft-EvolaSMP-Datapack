advancement revoke @s only evola_dp:eat_end_blob

execute if entity @s[y=-64, dy=66] in minecraft:the_end run return run function evola_dp:tp_end_bottom
execute if entity @s[y=253,dy=66] in minecraft:the_end run return run function evola_dp:tp_end_top
execute in minecraft:the_end run function evola_dp:tp_end_middle
