
execute in minecraft:overworld run forceload add ~-1 ~-1 ~1 ~1
execute in minecraft:the_nether run forceload add ~-1 ~-1 ~1 ~1
execute in minecraft:the_end run forceload add ~-1 ~-1 ~1 ~1

fill ~-1 ~-1 ~-1 ~1 ~2 ~1 minecraft:obsidian
fill ~ ~-1 ~ ~ ~2 ~ minecraft:crying_obsidian

fill ~1 ~-1 ~1 ~1 ~2 ~1 minecraft:crying_obsidian
fill ~-1 ~-1 ~-1 ~-1 ~2 ~-1 minecraft:crying_obsidian
fill ~1 ~-1 ~-1 ~1 ~2 ~-1 minecraft:crying_obsidian
fill ~-1 ~-1 ~1 ~-1 ~2 ~1 minecraft:crying_obsidian

fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:white_stained_glass_pane
fill ~ ~ ~ ~ ~1 ~ minecraft:air

execute in minecraft:overworld run forceload remove ~-1 ~-1 ~1 ~1
execute in minecraft:the_nether run forceload remove ~-1 ~-1 ~1 ~1
execute in minecraft:the_end run forceload remove ~-1 ~-1 ~1 ~1