execute in minecraft:the_nether run tp ~ ~ ~
execute in minecraft:the_nether run function evola_dp:build_rift_cage