execute positioned 0 0 0 positioned over motion_blocking run setblock ~ ~ ~ minecraft:dragon_egg
scoreboard players set #can_spawn_dragon_egg perm_data_holder 0
scoreboard players set #dragon_respawned perm_data_holder 0
