tag @s add pri_guardian

attribute @s max_health base set 200
data modify entity @s Health set value 200
attribute @s scale base set 2

bossbar add pri_guardian_bossbar {text:"Primordial Guardian", color:"blue"}
bossbar set pri_guardian_bossbar max 200
bossbar set pri_guardian_bossbar color blue
