execute positioned ^ ^ ^1 if block ~ ~ ~ air run function evola_dp:raytrace
particle sonic_boom
execute as @e[distance=..3] run damage @s 1000