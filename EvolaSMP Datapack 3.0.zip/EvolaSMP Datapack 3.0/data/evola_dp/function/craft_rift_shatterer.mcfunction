advancement revoke @s only evola_dp:craft_rift_shatterer

scoreboard players set #can_spawn_dragon_egg perm_data_holder 1
scoreboard players operation #ender_dragon_armour perm_data_holder += #ender_dragon_add_armour perm_data_holder

tellraw @a [{text:"A Rift Shatterer has been crafted by ",color:"dark_purple"},{selector:"@s",color:"dark_purple"},{text:"!",color:"dark_purple"}]
