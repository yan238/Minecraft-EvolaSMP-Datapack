advancement revoke @s only evola_dp:eat_lump_of_overworld

execute in minecraft:overworld run tp ~ ~ ~
execute in minecraft:overworld run function evola_dp:build_overworld_cage
