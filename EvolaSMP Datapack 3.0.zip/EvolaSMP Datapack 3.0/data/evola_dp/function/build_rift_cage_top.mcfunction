
execute in minecraft:overworld run forceload add ~-1 ~-1 ~1 ~1
execute in minecraft:the_nether run forceload add ~-1 ~-1 ~1 ~1
execute in minecraft:the_end run forceload add ~-1 ~-1 ~1 ~1

fill ~-1 252 ~-1 ~1 255 ~1 minecraft:obsidian
fill ~ 252 ~ ~ 255 ~ minecraft:crying_obsidian

fill ~1 252 ~1 ~1 255 ~1 minecraft:crying_obsidian
fill ~-1 252 ~-1 ~-1 255 ~-1 minecraft:crying_obsidian
fill ~1 252 ~-1 ~1 255 ~-1 minecraft:crying_obsidian
fill ~-1 252 ~1 ~-1 255 ~1 minecraft:crying_obsidian

fill ~-1 253 ~-1 ~1 254 ~1 minecraft:white_stained_glass_pane
fill ~ 253 ~ ~ 254 ~ minecraft:air

execute in minecraft:overworld run forceload remove ~-1 ~-1 ~1 ~1
execute in minecraft:the_nether run forceload remove ~-1 ~-1 ~1 ~1
execute in minecraft:the_end run forceload remove ~-1 ~-1 ~1 ~1