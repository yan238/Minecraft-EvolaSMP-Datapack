execute in evola_dp:the_rift run forceload add ~-1 ~-1 ~1 ~1

fill ~-1 ~-1 ~-1 ~1 ~2 ~1 minecraft:obsidian
fill ~ ~-1 ~ ~ ~2 ~ minecraft:crying_obsidian

fill ~1 ~-1 ~1 ~1 ~2 ~1 minecraft:end_stone_bricks
fill ~-1 ~-1 ~-1 ~-1 ~2 ~-1 minecraft:end_stone_bricks
fill ~1 ~-1 ~-1 ~1 ~2 ~-1 minecraft:end_stone_bricks
fill ~-1 ~-1 ~1 ~-1 ~2 ~1 minecraft:end_stone_bricks

fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:white_stained_glass_pane
fill ~ ~ ~ ~ ~1 ~ minecraft:air

execute in evola_dp:the_rift run forceload remove ~-1 ~-1 ~1 ~1