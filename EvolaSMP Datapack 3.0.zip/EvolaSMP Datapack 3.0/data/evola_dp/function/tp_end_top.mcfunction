execute in minecraft:the_end run tp ~ 253 ~
execute in minecraft:the_end run function evola_dp:build_rift_cage_top