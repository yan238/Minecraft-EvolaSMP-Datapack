execute positioned ^ ^ ^0.1 if block ~ ~ ~ air run return run function evola_dp:raytrace_loot_box
execute if predicate evola_dp:rc_001 positioned ^ ^ ^0.5 align xyz run function evola_dp:loot_box_boom
execute positioned ^ ^ ^0.5 run data modify block ~ ~ ~ components."minecraft:custom_data"."loot_box" set value false