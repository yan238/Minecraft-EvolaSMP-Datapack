advancement revoke @s only evola_dp:respawn_dragon

schedule function evola_dp:schedule_set_dragon_respawned 5