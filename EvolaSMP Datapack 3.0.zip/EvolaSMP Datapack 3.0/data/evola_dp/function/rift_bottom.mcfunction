
effect give @s minecraft:wither 5 255
execute if predicate evola_dp:rc_01 run summon minecraft:tnt ~ ~-1 ~ {fuse:0}
