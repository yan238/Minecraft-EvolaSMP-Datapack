execute in minecraft:the_nether run tp ~ 2 ~
execute in minecraft:the_nether run function evola_dp:build_rift_cage_bottom