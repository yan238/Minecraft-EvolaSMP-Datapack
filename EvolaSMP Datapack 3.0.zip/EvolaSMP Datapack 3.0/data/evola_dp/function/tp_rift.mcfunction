advancement revoke @s only evola_dp:eat_riftshard

execute in evola_dp:the_rift run tp @s ~ ~ ~

execute if dimension minecraft:overworld run return run execute in evola_dp:the_rift run function evola_dp:build_overworld_cage
execute if dimension minecraft:the_nether run return run execute in evola_dp:the_rift run function evola_dp:build_nether_cage
execute if dimension minecraft:the_end run return run execute in evola_dp:the_rift run function evola_dp:build_end_cage
