advancement revoke @s only evola_dp:rift_water

effect give @s minecraft:poison 5 9