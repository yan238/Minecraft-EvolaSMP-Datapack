execute in minecraft:the_end run tp ~ ~ ~
execute in minecraft:the_end run function evola_dp:build_rift_cage