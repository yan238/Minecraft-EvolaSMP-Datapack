advancement revoke @s only evola_dp:open_loot_box
execute anchored eyes run function evola_dp:raytrace_loot_box