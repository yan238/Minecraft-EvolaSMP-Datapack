advancement revoke @s only evola_dp:eat_netherstone

execute if entity @s[y=-64, dy=66] in minecraft:the_nether run return run function evola_dp:tp_nether_bottom
execute if entity @s[y=253,dy=66] in minecraft:the_nether run return run function evola_dp:tp_nether_top
execute unless entity @s[y=-64, dy=66] in minecraft:the_nether run function evola_dp:tp_nether_top
