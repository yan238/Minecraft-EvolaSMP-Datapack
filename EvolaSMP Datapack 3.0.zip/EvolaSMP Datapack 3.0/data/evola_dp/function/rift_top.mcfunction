
execute if predicate evola_dp:rc_01 run summon minecraft:lightning_bolt
attribute @s minecraft:gravity modifier add evola_dp:rift_top 100 add_multiplied_base
