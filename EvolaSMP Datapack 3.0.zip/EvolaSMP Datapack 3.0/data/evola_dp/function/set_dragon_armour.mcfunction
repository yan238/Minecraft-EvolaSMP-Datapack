execute store result storage evola_dp:temp ender_dragon_armour.value int 1 run scoreboard players get #ender_dragon_armour perm_data_holder
function evola_dp:change_armour with storage evola_dp:temp ender_dragon_armour

execute store result entity @s attributes[2].base int 1 run scoreboard players get #ender_dragon_armour perm_data_holder
tag @s add added_armour