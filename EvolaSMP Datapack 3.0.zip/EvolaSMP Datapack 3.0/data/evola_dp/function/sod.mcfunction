particle dragon_breath ~ ~ ~ 0.1 0.1 0.1 0.01 1
# execute positioned ^ ^ ^1 unless entity @e[distance=..3] run return run function evola_dp:sod
execute positioned ^ ^ ^1 if block ~ ~ ~ air run return run function evola_dp:sod
particle reverse_portal ~ ~ ~ 0 0 0 0.5 100
summon tnt ~ ~ ~ {fuse:0, explosion_power:5}