execute in minecraft:the_end run tp ~ 2 ~
execute in minecraft:the_end run function evola_dp:build_rift_cage_bottom