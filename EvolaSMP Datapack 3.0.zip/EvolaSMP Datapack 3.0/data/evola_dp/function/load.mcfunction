scoreboard objectives add temp_data_holder dummy
scoreboard players set #current_max_health temp_data_holder 0
scoreboard players set #add_health temp_data_holder 0

scoreboard objectives add boosted minecraft.used:minecraft.firework_rocket boosted

scoreboard objectives add Kills playerKillCount
scoreboard objectives add Deaths deathCount

scoreboard objectives add soul_meter dummy
scoreboard objectives add soul_spell_cooldown dummy

execute in minecraft:overworld run forceload add 0 0 0 0
execute in minecraft:the_nether run forceload add 0 0 0 0
execute in minecraft:the_end run forceload add 0 0 0 0
execute in evola_dp:the_rift run forceload add 0 0 0 0

scoreboard objectives add perm_data_holder dummy

execute unless score #onemace_crafted perm_data_holder matches 1 run scoreboard players set #onemace_crafted perm_data_holder 0

scoreboard objectives add player_die deathCount
execute unless score #id_counter perm_data_holder matches 1.. run scoreboard players set #id_counter perm_data_holder 0
scoreboard objectives add player_id dummy

execute unless score #dragon_alive perm_data_holder = #dragon_alive perm_data_holder run scoreboard players set #dragon_alive perm_data_holder 0
execute unless score #can_spawn_dragon_egg perm_data_holder = #can_spawn_dragon_egg perm_data_holder run scoreboard players set #can_spawn_dragon_egg perm_data_holder 0
execute unless score #dragon_respawned perm_data_holder = #dragon_respawned perm_data_holder run scoreboard players set #dragon_respawned perm_data_holder 0

scoreboard players set #ender_dragon_add_armour perm_data_holder 1
execute unless score #ender_dragon_armour perm_data_holder = #ender_dragon_health perm_data_holder run scoreboard players set #ender_dragon_armour perm_data_holder 0
