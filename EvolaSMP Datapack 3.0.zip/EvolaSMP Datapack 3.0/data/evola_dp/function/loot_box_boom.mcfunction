summon tnt ~0.5 ~ ~0.5 {fuse:0, explosion_power:1}
summon tnt ~0.5 ~ ~0.5 {fuse:5, explosion_power:50}
title @s title {text:"Gambled too hard", color:red, bold:true}